# Juno KB — 리포트 규격

**Version**: 1.0
**용도**: 산출물 HTML의 골격·디자인 토큰·컴포넌트·표기 규칙. **리포트를 작성하기 전에 항상 이 문서를 먼저 읽는다.**

이 규격은 회사가 바뀌어도 변하지 않는다. 바뀌는 것은 내용이지 형식이 아니다. **매번 새로 디자인하지 않는다.**

---

## 1. 문서 골격

### 1.1 셸 구조

```
<div class="shell">           그리드 250px + 1fr, max-width 1440px
  <aside class="rail">        좌측 고정 내비게이션 (sticky, 100vh)
  <main>
    <header class="mast">     전면 폭 헤더 (accent 배경)
    <div class="wrap">        max-width 1000px, padding 0 44px
      <section id="s0">...    섹션 반복
    <footer class="doc">
```

1080px 이하에서 rail이 상단으로 접히고 nav는 숨는다. 인쇄 시 rail·tooltip·toggle 제거.

### 1.2 섹션 순서

| 번호 | 성격 | 필수 | 내용 |
|---|---|---|---|
| 00 | 결론 | **필수** | 발견 요약. 카드 3개 + "이 진단이 답할 수 없었던 것" 경고 블록 |
| 01 | 전제 | **필수** | 이 리포트를 읽는 법. 산출 기준 설명 + 판독 삼분할 그리드 |
| 02 | 근거 | **필수** | 전체 그림. KPI 타일 4개 + 연도별 표 + 차트 |
| 03~07 | 근거 | 가변 | **발견 하나당 한 섹션.** 개수는 발견 수에 따라 3~6개 |
| 08 | 처방 | **필수** | 개선 벡터 3개 + 합산 효과 + 민감도 표 |
| 09 | 한계 | **필수** | 이 리포트의 한계. 못 본 것과 그 영향 |
| 10 | 부록 | **필수** | 아코디언. 가정 원장 / 근거 등급표 / 자료 목록 / 적용 기법 / 자체 점검 |

**개선 벡터는 근거 뒤에 둔다.** 결론(00)을 먼저 읽히고, 근거로 납득시킨 다음, 처방을 낸다. 처방을 앞에 두면 근거 없이 지시받는 문서가 된다. 대신 **00에서 금액을 미리 말해** 뒤에 뭐가 오는지 알린다.

**판독 가능성은 두 번 나온다.** 01에 요약(삼분할 그리드), 09에 전문. 앞에 요약을 둬야 독자가 숫자를 어디까지 믿을지 정한 상태로 읽는다.

---

## 2. 디자인 토큰

### 2.1 폰트

```css
--kr:'Pretendard Variable',Pretendard,-apple-system,BlinkMacSystemFont,
     'Apple SD Gothic Neo','Malgun Gothic','Noto Sans KR',sans-serif;
--num:'Inter','Pretendard Variable',Pretendard,system-ui,sans-serif;
--eb:'Oswald','Pretendard Variable',Pretendard,sans-serif;
```

```html
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Oswald:wght@400;500;600&display=swap">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/orioncactus/pretendard@v1.3.9/dist/web/variable/pretendardvariable-dynamic-subset.min.css">
```

- **본문 한글**: Pretendard
- **모든 숫자**: Inter + `font-variant-numeric:tabular-nums`. 표에서 자릿수가 맞아야 읽힌다
- **라벨·섹션번호·eyebrow**: Oswald 대문자, `letter-spacing:.14~.2em`

### 2.2 색

라이트 기준. 다크는 `prefers-color-scheme`과 `[data-theme]` 양쪽으로 지원한다.

| 변수 | 라이트 | 다크 | 용도 |
|---|---|---|---|
| `--plane` | `#F1F2F0` | `#0E1113` | 페이지 배경 |
| `--surface` | `#FFFFFF` | `#171B1E` | 카드·표 배경 |
| `--surface-2` | `#F7F8F6` | `#1D2225` | 표 헤더, hover, 보조 배경 |
| `--ink` | `#14181B` | `#F2F4F3` | 제목·강조 텍스트 |
| `--ink-2` | `#525A60` | `#AEB6BB` | 본문 |
| `--ink-3` | `#878F94` | `#7E878C` | 캡션·라벨 |
| `--rule` | `#DEE1DE` | `#2B3134` | 테두리 |
| `--rule-2` | `#EAEDEA` | `#23282B` | 표 내부 선 |
| `--accent` | `#123C4F` | `#8FC4D6` | 브랜드. 헤더 배경·섹션 번호·벡터 랭크 |
| `--accent-2` | `#1E5C74` | `#A9D4E3` | 링크 |
| `--accent-wash` | `#E8F0F3` | `#17323D` | accent 콜아웃 배경 |
| `--s1` | `#2a78d6` | `#3987e5` | 차트 계열 1 (유입·긍정 계열) |
| `--s2` | `#eb6834` | `#d95926` | 차트 계열 2 (지출) |
| `--s3` | `#1baf7a` | `#199e70` | 차트 계열 3 |
| `--good` | `#0ca30c` | 동일 | 양수·A등급 |
| `--warn` | `#fab219` | 동일 | 주의 |
| `--crit` | `#d03b3b` | `#e66767` | 음수·심각 |
| `--crit-wash` | `#FBECEC` | `#3A2222` | 심각 콜아웃 배경 |
| `--warn-wash` | `#FDF4E1` | `#332912` | 주의 콜아웃 배경 |
| `--good-wash` | `#E9F6E9` | `#16301A` | |

```css
--shadow:0 1px 2px rgba(20,24,27,.05), 0 8px 24px -12px rgba(20,24,27,.14);
```

다크 모드에서 mast 배경만 `#10262F`로 따로 내린다. accent를 그대로 쓰면 밝은 청록이라 헤더가 튄다.

### 2.3 타이포 스케일

| 요소 | 크기 | 비고 |
|---|---|---|
| body | 15px / 1.72 | `word-break:keep-all` **필수** |
| mast h1 | `clamp(30px,4.2vw,44px)` / 800 / `-.032em` | |
| mast lede | 16.5px / 1.7 / max 66ch | |
| section h2 | 26px / 700 / `-.028em` | |
| `.lead` | 17px / 500 / max 66ch | 섹션 첫 단락 |
| `.body` | 15px / max 70ch | 본문 |
| `.sec-sub` | 15px / `--ink-2` / max 70ch | 섹션 부제 |
| 표 | 13.4px | |
| 캡션·figcaption | 11.5~11.8px | |
| 타일 수치 | 27px / 600 / `-.03em` | |

**`word-break:keep-all`을 body에 반드시 건다.** 한글 단어가 줄바꿈에서 잘리면 가독성이 무너진다. 제목에는 `text-wrap:balance`.

---

## 3. 컴포넌트 카탈로그

### 3.1 mast (표지 헤더)

```html
<header class="mast">
  <div class="inner">
    <div class="eyebrow">
      <span>재무 판독 리포트</span>
      <span class="tag">전체 진단</span><span class="tag">현금 기준</span><span class="tag">대외비</span>
    </div>
    <h1>결론 문장을 여기에</h1>
    <p class="lede">무엇을 어떻게 읽었는지 3~4문장</p>
    <dl class="meta"><div><dt>Period</dt><dd>…</dd></div>…</dl>
  </div>
</header>
```

**h1은 회사 이름이 아니라 결론 문장이다.** "KRAFTEQUE 재무 분석"이 아니라 "5년간 54억을 벌어 54억 8천을 썼습니다". 첫 화면에서 결론이 끝나야 한다.

eyebrow tag에는 **진입 모드**와 **산출 기준**(현금 기준 / 발생주의)을 반드시 표시한다.

### 3.2 sec-head

```html
<div class="sec-head"><span class="no">03</span><h2>매출의 3분의 1이 이름 없이 들어옵니다</h2></div>
<p class="sec-sub">한 줄 부제</p>
<div class="rule"></div>
```

**섹션 제목은 주장문으로 쓴다.** "고객 구조 분석"이 아니라 "고객이 쌓이지 않습니다". 제목만 훑어도 리포트 전체 논지가 읽혀야 한다. 기법 이름은 제목에 절대 쓰지 않는다.

### 3.3 tiles (KPI)

```html
<div class="tiles">
  <div class="tile neg">
    <div class="lbl">누적 현금 수지 (대여금 회수 제외)</div>
    <div class="val num">−0.49<span class="u">억</span></div>
    <div class="note">유입 대비 −0.9%</div>
  </div>
</div>
```

4개가 기본. `.neg`는 crit 색, `.pos`는 good 색. `.note`에 산출 근거를 한 줄. **라벨에 조건을 명시한다.** "현금 수지"가 아니라 "누적 현금 수지 (대여금 회수 제외)".

### 3.4 finding (발견 카드)

```html
<div class="finding crit">
  <div class="fno">01</div>
  <div><h4>주장 한 문장</h4><p>근거 3~4문장, 핵심 수치는 <strong></strong></p></div>
</div>
```

`.crit` / `.warn` / 기본(accent) 세 단계. 00 섹션에 3개만.

### 3.5 callout

```html
<div class="callout crit">
  <div class="ct">이 진단이 답할 수 없었던 것</div>
  본문
</div>
```

| 변형 | 용도 |
|---|---|
| `.crit` | 판독 한계, 결론을 뒤집을 수 있는 전제, 위험 |
| `.warn` | 주의해서 읽어야 할 해석 |
| `.acc` | 한 줄 판정, 요약, 종합 |

`.ct`는 Oswald 대문자 라벨. **섹션마다 최소 하나의 `.acc` "한 줄 판정"을 둔다.** 독자가 그 섹션에서 뭘 가져가야 하는지 명시.

### 3.6 표

```html
<div class="tbl-wrap"><table>
  <thead><tr><th>항목 (억원)</th><th>2021</th>…</tr></thead>
  <tbody>
    <tr><td>직접 매출</td><td>8.10</td>…<td class="hi">37.06</td></tr>
    <tr class="sum"><td>총 유입</td>…</tr>
    <tr><td>현금 수지</td><td class="pos">+0.91</td><td class="neg">−1.34</td></tr>
  </tbody>
</table></div>
<p class="cap">표 아래 주석. 산출 조건과 예외.</p>
```

- 첫 열은 좌측 정렬·한글 폰트, 나머지는 우측 정렬·`tabular-nums`
- `.sum` 합계행, `.hi` 강조 셀, `.pos`/`.neg` 부호 색
- 근거 등급이 필요한 행은 항목명 옆에 `<span class="grade c">C</span>`
- **`.cap`은 선택이 아니다.** 표에는 반드시 산출 조건 주석을 붙인다

### 3.7 차트

**라이브러리를 쓰지 않는다.** `document.createElementNS`로 SVG를 직접 그린다. 이유는 셋이다. 파일이 단일 HTML로 닫히고, 색이 CSS 변수를 그대로 타서 다크 모드가 자동으로 되고, 인쇄가 깨지지 않는다.

```html
<figure>
  <div class="fig-title">연도별 유입·지출과 현금 수지</div>
  <div class="fig-sub">막대는 유입과 지출, 아래 숫자는 그 차이. 단위 억원.</div>
  <div class="legend"><span><i style="background:var(--s1)"></i>총 유입</span>…</div>
  <div class="chart" id="c-pl"></div>
  <figcaption>산출 조건과 주의사항</figcaption>
</figure>
```

**공통 규격**
- viewBox 폭 760, 높이 230~330. `width:100%`, `min-width:520px`로 좁은 화면에서 가로 스크롤
- 색은 반드시 `var(--s1)` 형태. 하드코딩 금지
- 모든 데이터 요소에 `bindTip()`으로 툴팁. 툴팁은 `position:fixed` 단일 노드 재사용
- 격자선 `var(--rule)`, 축 라벨 `var(--ink-3)` 11px
- 음수는 `−`(U+2212), 하이픈 아님

**필수 헬퍼**

```js
const NS='http://www.w3.org/2000/svg';
function el(n,a){const e=document.createElementNS(NS,n);for(const k in a)e.setAttribute(k,a[k]);return e;}
function svgRoot(host,w,h){host.innerHTML='';const s=el('svg',{viewBox:`0 0 ${w} ${h}`,width:'100%',role:'img'});
  s.style.display='block';s.style.minWidth=(w<520?w:520)+'px';host.appendChild(s);return s;}
function txt(p,x,y,t,o){const a=Object.assign({x,y,fill:'var(--ink-3)','font-size':11},o||{});
  const e=el('text',a);e.textContent=t;p.appendChild(e);return e;}
const fmt=(v,d=2)=>(v<0?'−':'')+Math.abs(v).toFixed(d);
```

**차트 유형 선택**: 연도별 비교는 그룹 막대, 분포는 가로 막대, 시계열 60개월은 라인+영역, 순위는 가로 막대 정렬, 구성비는 누적 막대. 원형 차트는 쓰지 않는다.

### 3.8 switch (전제 토글)

결론을 뒤집는 가정이 있을 때, **두 시나리오를 버튼으로 전환해 보여준다.**

```html
<div class="switch" role="group" aria-label="…">
  <button id="btn-incl" aria-pressed="true">매출로 본다</button>
  <button id="btn-excl" aria-pressed="false">매출이 아니라고 본다</button>
</div>
```

가정을 문장으로만 적으면 독자가 크기를 못 느낀다. 눌러서 숫자가 바뀌는 걸 보면 안다. **가정 원장에서 "틀리면 결론이 뒤집힌다"고 쓴 항목은 가능하면 토글로 구현한다.**

### 3.9 triage (판독 삼분할)

```html
<div class="triage">
  <div class="can"><h5>이 데이터로 답할 수 있는 것</h5><ul>…</ul></div>
  <div class="cant"><h5>이 데이터로 답할 수 없는 것</h5><ul>…</ul></div>
  <div class="get"><h5>받으면 열리는 것</h5><ul>…<span class="grade">난이도 낮음</span></ul></div>
</div>
```

색: can=good, cant=crit, get=s1. **세 칸 모두 채운다.** 가운데가 비면 판독이 얕은 것이다.

### 3.10 vec (개선 벡터)

```html
<div class="vec">
  <div class="vec-head">
    <span class="vec-rank">01</span>
    <div><h4>행동 문장</h4><p class="why">왜 이것인가</p></div>
  </div>
  <div class="vec-grid">
    <div><dt>연간 효과</dt><dd><span class="big">1,900만 ~ 3,000만원</span>공헌이익 기준<span class="grade c">C</span></dd></div>
    <div><dt>계산식</dt><dd>…</dd></div>
    <div><dt>첫 동작</dt><dd>… <strong>소요 2시간.</strong></dd></div>
    <div><dt>누가 언제</dt><dd>…</dd></div>
    <div><dt>부작용</dt><dd class="sfx">…</dd></div>
  </div>
</div>
```

- 제목은 **동사로 끝나는 행동 문장**. "고객 관리 강화"가 아니라 "4~5개년 거래한 32곳에 재발주 루틴을 건다"
- `.big`에 금액. **범위로 쓴다.** 단일 값은 없는 정밀도를 주장한다
- 첫 동작에는 **소요 시간을 분·시간 단위로** 박는다
- 부작용은 비워두지 않는다. 없으면 "없음"이라고 쓰고 대신 주의사항을 적는다
- 벡터 3개 뒤에 `.callout.acc` "세 개를 다 하면" + 중복 효과 상쇄 언급 + 민감도 표

### 3.11 grade (근거 등급 배지)

```html
<span class="grade a">A</span> <span class="grade b">B</span>
<span class="grade c">C</span> <span class="grade d">D</span>
<span class="grade">난이도 낮음</span>
```

A=good, B=s1, C=warn, D=ink-3. 라벨 없이 쓰면 회색 중립 배지가 되어 난이도·부가 라벨로 쓸 수 있다.

### 3.12 details (부록 아코디언)

```html
<details><summary>A. 가정 원장: 이 가정이 틀리면 결론이 어떻게 바뀌나</summary>
  <div class="dbody">…</div></details>
```

`+` / `–` 마커. 인쇄 시 전부 펼침(`details .dbody{display:block!important}`).

부록 순서: **A 가정 원장 / B 근거 등급표 / C 추가 자료 목록 / D 적용 기법과 선택 이유 / E 산출 방법 / F 자체 점검**.

### 3.13 chk (자체 점검 리스트)

```html
<ul class="chk"><li>진입 모드를 판정하고 선언했나</li><li class="no">해당 없음 항목</li></ul>
```

`✓` 체크, `.no`는 회색 점. 부록 마지막에 16항목 전부.

### 3.14 rail (좌측 내비)

브랜드 블록(mark / 회사명 / 기간) + 섹션 링크 + 하단 버튼(다크 모드 / 인쇄·PDF 저장) + 대외비 표기.

`IntersectionObserver`로 현재 섹션 하이라이트. `rootMargin:'-15% 0px -70% 0px'`.

---

## 4. 숫자·문장 표기 규칙

### 4.1 숫자

| 항목 | 규칙 |
|---|---|
| 단위 | 억원 기본, 소수 둘째 자리. 개선안 금액만 만원 단위 |
| 음수 | `−` (U+2212). 하이픈 `-` 금지 |
| 부호 | 증감에는 항상 `+`/`−` 명시 |
| 색 | 양수 `--good`, 음수 `--crit`. 색만으로 정보를 전달하지 않고 부호를 반드시 병기 |
| 반올림 | 셋째 자리 반올림. 합계 불일치 가능성을 footer에 명시 |
| 비율 | 소수 첫째 자리 |
| 폰트 | 전부 `.num` 클래스 |

### 4.2 문장

- **모든 주장에 금액이나 비율이 붙는다.** 형용사로 심각도를 표현하지 않는다
- "인건비 부담이 큽니다" (X) → "그해 매출의 47.7%가 인건비로 나갔습니다" (O)
- 강조는 `<strong>`으로 문장 안 핵심 수치·판정에만. 한 단락에 2개 이하
- 독자 호칭은 대표 기준. 지시는 청유가 아니라 단정 ("검토해 보시면 좋겠습니다" → "적용하지 마십시오")
- **현금 기준 리포트에서는 손익 용어를 쓰지 않는다.** 매출총이익·영업이익 대신 유입·지출·현금 수지
- 기법 이름은 제목·섹션명에 쓰지 않고 부록 D에만

### 4.3 footer

```html
<footer class="doc">
  <p><strong>이 문서는 재무 진단이며 세무 처리·감사 의견·투자 자문이 아닙니다.</strong> …산출 근거 명시…</p>
  <p>단위·반올림 규칙</p>
  <p>Juno · 재무 판독·개선 파트너 · 진단 기준일 YYYY-MM-DD · 대외비</p>
</footer>
```

---

## 5. 접근성·인쇄

- `prefers-reduced-motion`에서 애니메이션·스무스 스크롤 해제
- 모든 인터랙티브 요소에 `:focus-visible` 아웃라인 (accent 2px)
- SVG에 `role="img"`
- 색만으로 정보를 전달하지 않는다. 부호·라벨 병기
- 인쇄: rail·tooltip·switch 숨김, `page-break-inside:avoid`를 section·figure·vec·tbl-wrap에, mast 배경 강제 출력(`print-color-adjust:exact`)

---

## 6. 다른 산출물에의 적용

**13주 현금흐름 계획**은 같은 토큰과 컴포넌트를 쓰되 다음이 다르다.

- eyebrow tag를 `현금 계획` / `근거 등급 C·D` 로 표시. **진단 리포트와 섞이지 않게 문서 성격을 표지에서 구분**
- mast 배경을 accent가 아닌 `--surface-2` + accent 테두리로. 색으로 문서 종류를 구분
- 주 단위 표가 중심. 13열이라 `.tbl-wrap` 가로 스크롤 전제
- 최저 잔고 시점은 `.tiles`의 `.neg` 타일로 전면 배치
- 시나리오 3종은 `.switch`로 전환

**장부 설계서**는 표지 h1을 결론이 아니라 목표 문장으로 쓴다. "6개월 뒤에 무엇이 보이게 만드는가".

**사용 브리프·제안서** 등 대외 문서도 같은 토큰을 쓴다. 문서마다 디자인이 다르면 개인 작업물처럼 읽힌다.

---

**End of KB**
